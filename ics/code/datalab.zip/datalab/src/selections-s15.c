#include "bitAnd.c"
#include "tmin.c"

#include "negate.c"
#include "allEvenBits.c"
#include "bitCount.c"

#include "logicalShift.c"
#include "isNegative.c"
#include "isGreater.c"
#include "isPower2.c"

#include "fitsBits.c"
#include "conditional.c"
#include "greatestBitPos.c"

#include "float_i2f.c"
#include "float_abs.c"



