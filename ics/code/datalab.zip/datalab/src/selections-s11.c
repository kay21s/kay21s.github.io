#include "isTmin.c"
#include "tmax.c"

#include "fitsBits.c"
#include "leastBitPos.c"
#include "oddBits.c"
#include "sign.c"

#include "isGreater.c"
#include "subOK.c"
#include "conditional.c"
#include "replaceByte.c"
#include "satMul3.c"

#include "howManyBits.c"

#include "float_i2f.c"
