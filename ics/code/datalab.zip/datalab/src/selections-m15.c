#include "bitOr.c"
#include "tmin.c"

#include "negate.c"
#include "getByte.c"
#include "divpwr2.c"

#include "logicalShift.c"
#include "isPositive.c"
#include "isLess.c"

#include "bang.c"
#include "isPower2.c"
#include "ilog2.c"

#include "float_half.c"
#include "float_i2f.c"



