//1
#include "bitNor.c"
#include "tmax.c"

//2
#include "implication.c"
#include "divpwr2.c"
#include "isNegative.c"

//3
#include "conditional.c"
#include "rotateRight.c"

//4
#include "absVal.c"
#include "bang.c"
#include "greatestBitPos.c"

//float
#include "float_abs.c"
#include "float_pwr2.c"
#include "float_i2f.c"
