//1
#include "bitOr.c"
#include "specialBits.c"

//2
#include "isZero.c"
#include "anyEvenBit.c"
#include "negate.c"
#include "leastBitPos.c"

//3
#include "rotateLeft.c"
#include "divpwr2.c"
#include "isLess.c"

//4
#include "isPower2.c"
#include "bitReverse.c"

//float
#include "float_abs.c"
#include "float_i2f.c"
#include "float_times64.c"
