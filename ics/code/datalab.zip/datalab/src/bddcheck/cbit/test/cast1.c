unsigned fun(int x) {
  return  x + 0u;
}
