int test_trueThreeFourths(int x)
{
    long long int x3 = (long long int) x * 3;
    return (int) (x3/4);
}
