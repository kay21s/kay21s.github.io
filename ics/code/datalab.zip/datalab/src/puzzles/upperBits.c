#ifdef PROTOTYPE
int upperBits(int);
int test_upperBits(int);
#endif
#ifdef DECL
 {"upperBits", (funct_t) upperBits, (funct_t) test_upperBits, 1, "! ~ & ^ | + << >>", 10, 1,
  {{0, 32},{TMin,TMax},{TMin,TMax}}},
#endif
#ifdef CODE
/* 
 * upperBits - pads n upper bits with 1's
 *  You may assume 0 <= n <= 32
 *  Example: upperBits(4) = 0xF0000000
 *  Legal ops: ! ~ & ^ | + << >>
 *  Max ops: 10
 *  Rating: 1
 */
int upperBits(int n) {
#ifdef FIX
  return (((!!n)<<31)>>31) & ( (1<<31) >> (n+(~0)) );
#else
  return 2;
#endif
}
#endif
#ifdef TEST
int test_upperBits(int x) {
  int result = 0;
  int i;
  for (i = 0; i < x; i++)
    result |= (1 << (31-i));
  return result;
}
#endif
