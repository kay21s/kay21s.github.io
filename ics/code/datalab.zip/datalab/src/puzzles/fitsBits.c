#ifdef PROTOTYPE
int fitsBits(int, int);
int test_fitsBits(int, int);
#endif
#ifdef DECL
 {"fitsBits", (funct_t) fitsBits, (funct_t) test_fitsBits, 2,
    "! ~ & ^ | + << >>", 15, 2,
  {{TMin, TMax},{1,32},{TMin,TMax}}},
#endif
#ifdef CODE
/* 
 * fitsBits - return 1 if x can be represented as an 
 *  n-bit, two's complement integer.
 *   1 <= n <= 32
 *   Examples: fitsBits(5,3) = 0, fitsBits(-4,3) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 15
 *   Rating: 2
 */
int fitsBits(int x, int n) {
#ifdef FIX
  int shift = 32 + ~n + 1;
  int move = (x << shift) >> shift;
  return !(x ^ move);
#else
  return 2;
#endif
}
#endif
#ifdef TEST
int test_fitsBits(int x, int n)
{
  int TMin_n = -(1 << (n-1));
  // This convoluted way of generating TMax avoids overflow
  int TMax_n = (int) ((1u << (n-1)) - 1u);
  return x >= TMin_n && x <= TMax_n;
		
}
#endif
