#ifdef PROTOTYPE
int bitMask(int, int);
int test_bitMask(int, int);
#endif
#ifdef DECL
 {"bitMask", (funct_t) bitMask, (funct_t) test_bitMask, 2,
    "! ~ & ^ | + << >>", 16, 3,
  {{0, 31},{0,31},{TMin,TMax}}},
#endif
#ifdef CODE
/* 
 * bitMask - Generate a mask consisting of all 1's 
 *   lowbit and highbit
 *   Examples: bitMask(5,3) = 0x38
 *   Assume 0 <= lowbit <= 31, and 0 <= highbit <= 31
 *   If lowbit > highbit, then mask should be all 0's
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 16
 *   Rating: 3
 */
int bitMask(int highbit, int lowbit) {
#ifdef FIX
  int on = (2<<highbit) + ~0;
  int off = (1<<lowbit) + ~0;
  return on & ~off;
#else
  return 2;
#endif
}
#endif
#ifdef TEST
int test_bitMask(int highbit, int lowbit)
{
  int result = 0;
  int i;
  for (i = lowbit; i <= highbit; i++)
    result |= 1 << i;
  return result;
}
#endif
